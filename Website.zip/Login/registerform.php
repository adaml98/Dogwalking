<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="registerform.php">
  	<div class="input-group">
  	  <label>Username: </label>
  	  <input type="text" name="regUser" value= "<?php echo $username; ?>"/>
  	</div>
  	<div class="input-group">
  	  <label>Email: </label>
  	  <input type="text" name="regEmail" value= "<?php echo $email; ?>" />
  	</div>
  	<div class="input-group">
  	  <label>Password: </label>
  	  <input type="text" name="regPass1" >
  	</div>
  	<div class="input-group">
  	  <label>Confirm password: </label>
  	  <input type="text" name="regPass2">
  	</div>
  	<div class="input-group">
  	  <label>Age: </label>
  	  <select name="regAge">
      <option value="">Select...</option>
      <option value="under18">Under 18 </option>
      <option value="18+">18-35</option>
      <option value="36+">36-55</option>
      <option value="56+">56+</option>
      </select>
  	</div>
  	
  	<label class="container">I agree to the terms and conditions.
    <input type="checkbox">
    <span class="checkmark"></span>
    </label>
  	
  	<div class="input-group">
  	  <button type="submit" class='btn' name="regSubmit" value="submit">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="loginform.php">Sign in</a>
  		<a href="../home.php">Home</a>
  	</p>
  </form>
</body>
</html>