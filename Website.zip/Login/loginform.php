<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
  
  <form method="post" action="./login.php">
    <div class="input-group">
      <label>Username: </label>
      <input type="text" name="txtUser" value="<?php echo $_POST['txtUser']?>" />
    </div>
  	<div class="input-group">
  	  <label>Password: </label>
      <input type="password" name="txtPass" />
    </div>
  	<div class="input-group">
      <button type="submit" class='btn' name="subLogin" value="submit">Submit</button>
    </div>

    <p>
        <a href="registerform.php">Register</a>
        <a href="../home.php">Home</a>
    </p>

</form>
</body>
</html>