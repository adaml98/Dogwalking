<?php
include 'init.php';
if(!isset($_SESSION['user'])){
 header ('location:website.php');
}
?>