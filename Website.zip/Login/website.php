<!DOCTYPE html>
<html>
 <head>
 <title></title>
 <link rel="stylesheet" type="text/css" href="style.css">
 </head>
 <body>
 <p>
<?php
//include init.php so session vars can be used
include 'init.php';
//Use an if statement to determine whether the session var holding
//the user name ($_SESSION['user'] has been set. If it has, echo out
//a welcome message for the user, followed by a links to a pages
//called protected.php and logout.php.
if(isset($_SESSION['user'])){
    echo 'Welcome '.$_SESSION['user'].'<br>';
    echo '<a href="logout.php">logout</a>';
    echo '<a href="protected.php"></a><br>';
    echo '<a href="../home.php">Home</a>';
    
}elseif(isset($_SESSION['admin'])){
    echo 'Welcome '.$_SESSION['admin'].'<br>';
    echo '<a href="logout.php">logout</a>';
    echo '<a href="protected.php"></a><br>';
    echo '<a href="../home.php">Home</a>';
    
}else{
    include 'loginform.php';
    echo $_SESSION['error'];
}

//add an else section that will include loginform.php and display any
//error message that is held in ($_SESSION['error']
?>
</p>
</div>

 </body>
</html>