<?php
include 'init.php';
//Gather details submitted from the $_POST array and store in local vars
$user = $_POST['txtUser'];
$pass = $_POST['txtPass'];
//build query to SELECT records from the users table WHERE
//the username AND password in the table are equal to those entered.

$query = "SELECT * FROM webusers WHERE userName = '$user' AND userPass = '$pass'";
//run query and store result
$result = mysqli_query($connection, $query);
//check result and generate message with code below
if ($row = mysqli_fetch_assoc($result)) {
    
    if ($row['admin'] == 1){
        $_SESSION['admin']=$user;
        header ('location:website.php');
    }else{
        $_SESSION['user']=$user;
    }
    


header ('location:website.php');

} else 
{
    
$_SESSION['error']= 'User not recognised';
header ('location: website.php');
}
?>