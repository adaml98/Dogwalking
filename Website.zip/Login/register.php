<?php
include 'ShowErrors.php';
include 'init.php';
//Gather details submitted from the $_POST array and store in local vars
//if ($_POST['regSubmit']){
if (!empty($username)&&(!empty($email)&&(!empty($pass1)&&(!empty($pass2)&&(!empty($age)){
    
}else{
    echo'All fields required.'}
    
$username = $_POST['regUser'];
$email = $_POST['regEmail'];
$pass1 = $_POST['regPass1'];
$pass2 = $_POST['regPass2'];
$age = $_POST['regAge'];

/*
$error_check = array();

if(!empty($username)){
    $userName = cleanString($userName);
    $query="SELECT * FROM webusers WHERE userName=$username";
    $result=mysqli_query($connection, $query) or exit ("Error in query: $query");
    if(mysqli_num_rows($result) > 0){
        error_check['user'] = 'Username in use';
        
    }
    if (strlen($username)<6){
        $error_check['user'] = 'Username must be atleast 6 characters';
    }
    
    if ((!empty($pass1))&&(!empty($pass2))) {
        $pass1 = cleanString($pass1)
        $pass2 = cleanString($pass2);
        //are password identical
        if ($pass1!==$pass2){
            $error_check['repeat'] = 'Passwords do not match';
        }
        else{
            $pass1=sha1($pass1);
            
        }
    }
    
    
} 
*/



//insert into database

 $query="INSERT INTO webusers
(userName, userPass, userEmail, userAge, Admin)
VALUES
('$username', '$pass1', '$email', '$age', '0')";


mysqli_query($connection, $query);


?>