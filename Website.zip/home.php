<!DOCTYPE html>
<html>
<head>
	<link href="response.css" rel="stylesheet" type="text/css" />
	<title>WAT</title>
</head>
<body>
    <div id="pagewrap">
        <header>
    	    <h1>WAT Website</h1>
    	    <h2> Home Page </h2>
        </header>
    	<nav>
        	<ul id="navlist">
        		<li id="active">
        			<a href="home.php" id="current">&nbsp;Home &nbsp;&nbsp; </a>
        		</li>
        		
        		<li>
        			<a href="Login/loginform.php">Login</a>
        		</li>
        		<li>
        			<a href="adminPage.php">Admin</a>
        		</li>
        	</ul>
        </nav>

        
        	<h2>Content</h2>
        	
<a href="home.php">All</a><br>
<a href="home.php?cat=gift">Gift</a><br>
<a href="home.php?cat=clothing">Clothing</a><br></br>
                <?php 	
                     include 'Items/DisplayRecord.php';
                ?>
        
        
        	
        
        
        <footer>
			<?php
			
			echo '<a href="Login/logout.php">logout</a>' ;
			?>
		</footer>
	</div>
</body>
</html>
