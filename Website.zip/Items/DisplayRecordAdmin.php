<?php
//Make connection to database
include 'connection.php';
//create a query to select all records from products table
echo '<h1>Manage Products</h1>';
$query = "SELECT * FROM products";
//run query and store the result in a variable called $result
$result=mysqli_query($connection, $query);
//Use a while loop to iterate through your $result array and display
echo '<table style="width:35%" border="1" cellspacing="0" cellpadding="2">';
echo "<th> Product Name </th>";
echo "<th> Price </th>";
echo "<th> Image </th>";
echo "<th> Amend </th>";
echo "<th> Delete </th>";
while ($row=mysqli_fetch_assoc($result)){
echo '<tr>';
echo "<td>". $row['ProductName'].' </td><td> '.$row['ProductPrice'].'</td><td><img src="./Items/images/'.$row['ProductImageName'].'" />'."</td>";
echo '<td>'.'<a href="./Items/AmendProduct.php?id='. $row['ProductID'].'">Amend</a>'.'</td>';
echo '<td>'.'<a href="./Items/DeleteProduct.php?id='. $row['ProductID'].'">Delete</a>'.'</td>';
echo '</tr>';
}
echo '</table>';
echo '<br/>';
//ProductName, ProductPrice, ProductImageName.
?>

<form method="post" action="InsertProduct.php">
<fieldset>
<label for="">Product Name: </label><br />
<input type="text" name="txtProduct" value="" /><br /><br />
<label for="">Price: </label><br />
<input type="text" name="txtPrice" value="" /><br /><br />
<label for="">Image Filename: </label><br />
<input type="text" name="txtImg" value="" /><br /><br />
<input type="submit" value="Submit" name=""/>
<input type="reset" value="Clear" />
</fieldset>
</form>