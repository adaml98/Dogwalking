<?php
include './Login/showErrors.php';
include './Login?init.php';
$query = "SELECT * FROM Products";
if (isset($_POST['subSearch'])){
    $order=$_POST['radOrder'];
    $type=$_POST['selType'];
    $search=$_POST['txtSearch'];
    if($type!== 'ALL'){
        $query = $query." WHERE category = '$type'";
    }
    if($type!== 'All'&&(!empty($search))){
        $query=$query." AND content LIKE '%$search%'";
    }
    if($type!== 'All'&&(!empty($search))){
        $query = $query." WHERE content LIKE '%$search%'";
    }
    if(!empty($order)){
        $query=$query." ORDER BY $order";
    }
    echo $query;
    exit;
    $_SESSION['query']=$query;
    $_SESSION['searchSubmit']=$_POST['subSearch'];
    $_SESSION['order']=$order;
    $_SESSION['type']=$type;
    $_SESSION['search']=$search;
}
>