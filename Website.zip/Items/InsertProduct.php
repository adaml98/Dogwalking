<?php
//Make connection to database
include 'connection.php';

if(isset($_POST['subProduct'])){
//Gather from $_POST[]all the data submitted and store in variables
$product =$_POST['txtProduct'];
$price =$_POST['txtPrice'];
$image =$_POST['txtImg'];
//Construct INSERT query using variables holding data gathered
$query="INSERT INTO products
(ProductName, ProductPrice, ProductImageName)
VALUES
('$product', '$price', '$image')";
//run $query
mysqli_query($connection, $query);
 }
//return to calling page(stored in the server variables)
header("Location: {$_SERVER['HTTP_REFERER']}");
?>