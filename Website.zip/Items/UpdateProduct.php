<?php

include 'connection.php';

$id=$POST['txtProductID'];
$name=$_POST['txtProductName'];
$price=$_POST['txtProductPrice'];
$image=$_POST['txtProductImage'];

$query = "UPDATE Products
SET
ProductName
ProductPrice
ProductImage
WHERE
ProductID='$id'"

mysqli_query($connection, $query);
header("Location: watWk8.php");

?>