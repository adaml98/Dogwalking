<?php
include 'Login/init.php';
if(!isset($_SESSION['admin'])){
 header ('location:home.php');
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <link href="./response.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="pagewrap">
        <header>
    	    <h1>WAT Website</h1>
    	    <h2> Admin Page </h2>
        </header>
    	<nav>
        	<ul id="navlist">
        		<li id="active">
        			<a href="home.php" id="current">&nbsp;Home &nbsp;&nbsp; </a>
        		</li>
        		
        		<li>
        			<a href="Login/loginform.php">Login</a>
        		</li>
        		<li>
        			<a href="adminPage.php">Admin</a>
        		</li>
        	</ul>
        </nav>
  <div class="header">
  	<h2> Admin </h2>
  </div>
  
  <?php
  include 'Items/DisplayRecordAdmin.php';
  ?>
   
</body>
</html>